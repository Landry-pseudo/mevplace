<?php
namespace Config;

use CodeIgniter\Config\BaseConfig;

class Cors extends BaseConfig
{
    public $allowedOrigins = ['http://localhost:5173', 'http://127.0.0.1:5173'];
    public $allowedMethods = ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'];
    public $allowedHeaders = ['Content-Type', 'Authorization', 'X-Requested-With'];
    public $exposedHeaders = [];
    public $maxAge = 0;
    public $supportsCredentials = false;
}