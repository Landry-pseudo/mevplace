<?php
namespace App\Controllers\Api;

use CodeIgniter\RESTful\ResourceController;
use App\Models\UserModel;
use Config\Services;

class Auth extends ResourceController
{
    protected $model;
    protected $validation;
    
    public function __construct()
    {
        $this->model = new UserModel();
        $this->validation = Services::validation();
    }
    
    public function register()
    {
        // Règles de validation
        $rules = [
            'username' => 'required|min_length[3]|max_length[100]|is_unique[users.username]',
            'email'    => 'required|valid_email|is_unique[users.email]',
            'password' => 'required|min_length[6]'
        ];
        
        if (!$this->validate($rules)) {
            return $this->failValidationErrors($this->validator->getErrors());
        }
        
        $data = [
            'username' => $this->request->getPost('username'),
            'email'    => $this->request->getPost('email'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT)
        ];
        
        try {
            $userId = $this->model->insert($data);
            
            if ($userId) {
                return $this->respond([
                    'status' => 'success',
                    'message' => 'Utilisateur créé avec succès',
                    'data' => [
                        'user_id' => $userId
                    ]
                ]);
            } else {
                return $this->fail('Erreur lors de la création du compte');
            }
        } catch (\Exception $e) {
            return $this->fail('Erreur serveur: ' . $e->getMessage());
        }
    }
    
    // public function login()
    // {
    //     $rules = [
    //         'email'    => 'required|valid_email',
    //         'password' => 'required'
    //     ];
        
    //     if (!$this->validate($rules)) {
    //         return $this->failValidationErrors($this->validator->getErrors());
    //     }
        
    //     $email = $this->request->getPost('email');
    //     $password = $this->request->getPost('password');
        
    //     $user = $this->model->where('email', $email)->first();
        
    //     if ($user && password_verify($password, $user['password'])) {
    //         // Générer un token (simplifié pour l'exemple)
    //         $token = bin2hex(random_bytes(32));
            
    //         // Enregistrer le token en session
    //         session()->set([
    //             'user_id' => $user['id'],
    //             'username' => $user['username'],
    //             'email' => $user['email'],
    //             'token' => $token
    //         ]);
            
    //         return $this->respond([
    //             'status' => 'success',
    //             'message' => 'Connexion réussie',
    //             'data' => [
    //                 'user' => [
    //                     'id' => $user['id'],
    //                     'username' => $user['username'],
    //                     'email' => $user['email']
    //                 ],
    //                 'token' => $token
    //             ]
    //         ]);
    //     }
        
    //     return $this->failUnauthorized('Email ou mot de passe incorrect');
    // }
    public function login()
{
    $rules = [
        'email'    => 'required|valid_email',
        'password' => 'required'
    ];
    
    if (!$this->validate($rules)) {
        return $this->failValidationErrors($this->validator->getErrors());
    }
    
    $email = $this->request->getPost('email');
    $password = $this->request->getPost('password');
    
    $user = $this->model->where('email', $email)->first();
    
    if ($user && password_verify($password, $user['password'])) {
        // Générer un token (simplifié pour l'exemple)
        $token = bin2hex(random_bytes(32));
        
        // Enregistrer le token en session
        session()->set([
            'user_id' => $user['id'],
            'username' => $user['username'],
            'email' => $user['email'],
            'token' => $token
        ]);
        
        return $this->respond([
            'status' => 'success',
            'message' => 'Connexion réussie',
            'data' => [
                'user' => [
                    'id' => $user['id'],
                    'username' => $user['username'],
                    'email' => $user['email'],
                    'bio' => $user['bio']
                ],
                'token' => $token
            ]
        ]);
    }
    
    return $this->failUnauthorized('Email ou mot de passe incorrect');
}
    public function logout()
    {
        session()->destroy();
        return $this->respond([
            'status' => 'success',
            'message' => 'Déconnexion réussie'
        ]);
    }
    
    public function checkAuth()
    {
        $userId = session()->get('user_id');
        
        if ($userId) {
            $user = $this->model->find($userId);
            return $this->respond([
                'status' => 'success',
                'data' => [
                    'user' => [
                        'id' => $user['id'],
                        'username' => $user['username'],
                        'email' => $user['email']
                    ]
                ]
            ]);
        }
        
        return $this->failUnauthorized('Non authentifié');
    }
}